import './Project.css'
import React from 'react'
const Project = (props)=>
{
    return (
        <React.Fragment>
            <h1>Project </h1>
            <h3>Attendence Management System </h3>
            <ul>
                {
                    props.techstack.map((item,index) =>
                    {
                        return (
                            <li key={index}>{item}</li>
                        )
                    }
                    )
                }
            </ul>
        </React.Fragment>
    )
}
export default Project;