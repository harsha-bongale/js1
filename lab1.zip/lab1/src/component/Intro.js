import "./intro.css"
function Intro(props)
{
    return(
       
        <div>
            <h1>Introduction </h1>
            <div className="Introduction"></div>
                <div className="name">{props.name}</div>
                <div className="mail">{props.mail}</div>
                <div className="address">{props.address}</div>
            </div>  
    );
}
export default Intro;