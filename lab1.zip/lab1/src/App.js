import './App.css';
import Intro from '/home/harsha/Documents/lab1/src/component/Intro'
import Project from '/home/harsha/Documents/lab1/src/component/Project'
import Qualification from '/home/harsha/Documents/lab1/src/component/Qualification'
import React from 'react';

class App extends React.Component
{
  constructor(props)
  {
    super(props)
    this.state={
                  name:"Harsha",
                  mail : "harshaeb.mca20@rvce.edu.in",
                  address : "#404, paras apartment, pattanager, Bangalore 560059",
                  qualificaton :
                  [
                    {
                    college: "RVCE",
                    study : "MCA",
                    marks : 8.00
                    },
                    {
                      college: "SRNM",
                      study : "BCA",
                      marks : 7.00
                    },
                    {
                      college: "GPUC",
                      study : "PUC",
                      marks : 6.50
                      }
                  ],
                  techstack:["mangodb","experss.js","React.js"]
    }
  }
  render()
  {
    return (
      <React.Fragment>
        <Intro name={this.state.name}
                mail={this.state.mail}
                address={this.state.address} />
        <Qualification 
          qualification={this.state.qualificaton} />
        <Project
        techstack={this.state.techstack} />
      </React.Fragment>
    )
  }
}
export default App;
